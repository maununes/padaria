var app = angular.module('app', ['ngRoute','appControllers']);

var appControllers = angular.module('appControllers', []);

app.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            when('/', {
                templateUrl: 'views/home.html',
                controller: 'HomeController'
            }).
            when('/:id', {
                templateUrl: 'views/home.html',
                controller: 'HomeController'
            }).
            otherwise({
                redirectTo: '/views/error.html'
            });
    }]);

//Configurações de página, todo controller deve definir o seu
var config = {
    isNavbarVisible: false,
    pageTittle: ""
}

