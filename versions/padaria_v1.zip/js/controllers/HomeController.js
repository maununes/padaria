//Model cadastro
var cadastro = {
    nome:       null,
    email:      null,
    condominio: null,
    cidade:     null,
    comentario: null,
    data_hora:  null,
}

appControllers.controller('HomeController', ['$scope', '$routeParams', '$http', function ($scope,$routeParams, $http) {
    //Config
    $scope.config = config;
    $scope.config.isNavbarVisible = false;
    $scope.config.pageTittle = "Café Diem - Peça seu café da manhã em casa e aproveite o seu dia!";

    //Definindo model
    $scope.cadastro = cadastro;

    //Action save
    $scope.actionSaveCadastro = function(){
        $scope.cadastro.data_hora = getNow("datahora");

        var jsonCadastro = JSON.stringify($scope.cadastro);
        var url = 'http://minhaurl.com/?';
        $http.get(url+"cadastro="+jsonCadastro).success(function(data) {
            alert('enviou com sucesso!');
        });
        print($scope.cadastro);
    }//fim actionSaveCadastro


}]);//fim controller